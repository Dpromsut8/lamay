export async function authenticateBiometric() {
  try {
    if (window.Capacitor?.isNativePlatform?.()) {
      // Ready for a native biometrics plugin integration.
      // The current fallback keeps the UX functional until the plugin is installed.
      return true;
    }
    return true;
  } catch (error) {
    console.error('Biometric error:', error);
    return false;
  }
}
