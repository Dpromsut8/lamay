import React, { useMemo, useState } from 'react';

const initial = [
  {id:1,name:'ไก่ไข่',group:'สัตว์เลี้ยง',qty:38,unit:'ตัว',price:240,status:'ดี',icon:'🐔'},
  {id:2,name:'ปลานิล',group:'สัตว์เลี้ยง',qty:420,unit:'ตัว',price:8,status:'ดี',icon:'🐟'},
  {id:3,name:'มะกรูด',group:'พืชสวน',qty:76,unit:'ลูก',price:20,status:'ดี',icon:'🌿'},
  {id:4,name:'เห็ดนางฟ้าภูฐาน',group:'พืชสวน',qty:12,unit:'กก.',price:15,status:'ใกล้หมด',icon:'🍄'},
  {id:5,name:'ปั๊มน้ำอินเวอร์เตอร์',group:'วัสดุสิ้นเปลือง',qty:1,unit:'ตัว',price:2590,status:'ดี',icon:'⚙️'},
];

export default function Inventory(){
  const [items,setItems]=useState(()=>{try{return JSON.parse(localStorage.getItem('lamay_inventory'))||initial}catch{return initial}});
  const [query,setQuery]=useState('');
  const [group,setGroup]=useState('ทั้งหมด');
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({name:'',qty:'',unit:'ตัว',price:'',group:'พืชสวน'});
  const groups=['ทั้งหมด',...new Set(items.map(i=>i.group))];
  const filtered=useMemo(()=>items.filter(i=>(group==='ทั้งหมด'||i.group===group)&&i.name.toLowerCase().includes(query.toLowerCase())),[items,query,group]);
  const save=list=>{setItems(list);localStorage.setItem('lamay_inventory',JSON.stringify(list))};
  const add=e=>{e.preventDefault();if(!form.name.trim())return;save([...items,{id:Date.now(),name:form.name.trim(),qty:Number(form.qty)||0,unit:form.unit,price:Number(form.price)||0,status:Number(form.qty)>2?'ดี':'ใกล้หมด',group:form.group,icon:'📦'}]);setForm({name:'',qty:'',unit:'ตัว',price:'',group:'พืชสวน'});setShowAdd(false)};
  return <div className="page-stack">
    <section className="section-card">
      <div className="section-heading"><div><span className="section-kicker">INVENTORY</span><h2>คลังสินค้า <span className="muted">{items.length} รายการ</span></h2></div><button className="button primary compact" onClick={()=>setShowAdd(!showAdd)}>＋ เพิ่มรายการ</button></div>
      {showAdd&&<form className="add-form" onSubmit={add}><label>ชื่อรายการ<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="เช่น ปุ๋ยอินทรีย์"/></label><label>จำนวน<input type="number" min="0" value={form.qty} onChange={e=>setForm({...form,qty:e.target.value})}/></label><label>หน่วย<select value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})}><option>ตัว</option><option>กก.</option><option>ลูก</option><option>ถุง</option><option>ขวด</option></select></label><label>ราคากลาง (บาท)<input type="number" min="0" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></label><label>กลุ่ม<select value={form.group} onChange={e=>setForm({...form,group:e.target.value})}><option>พืชสวน</option><option>สัตว์เลี้ยง</option><option>วัสดุสิ้นเปลือง</option></select></label><button className="button primary" type="submit">บันทึกรายการ</button></form>}
      <div className="inventory-toolbar"><div className="search-wrap small"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="ค้นหาในคลัง..."/></div><div className="chip-row">{groups.map(g=><button className={`chip ${group===g?'active':''}`} key={g} onClick={()=>setGroup(g)}>{g}</button>)}</div></div>
      <div className="inventory-table"><div className="inventory-head"><span>รายการ</span><span>คงเหลือ</span><span>ราคากลาง</span><span>สถานะ</span></div>
      {filtered.map(i=><div className="inventory-row" key={i.id}><div className="item-name"><span>{i.icon}</span><div><b>{i.name}</b><small>{i.group}</small></div></div><strong>{i.qty.toLocaleString('th-TH')} <small>{i.unit}</small></strong><span>฿{i.price.toLocaleString('th-TH')}</span><span className={`badge ${i.status==='ดี'?'success':'warning'}`}>{i.status}</span></div>)}
      {filtered.length===0&&<div className="empty">ไม่พบรายการที่ค้นหา</div>}</div>
    </section>
  </div>;
}
