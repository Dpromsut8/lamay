import React, { useState } from 'react';
import './Login.css';
import { authenticateBiometric } from '../utils/nativeBiometrics';

export default function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState('Admin');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const login = (e) => {
    e.preventDefault();
    setError('');
    if (!username.trim()) return setError('กรุณาระบุชื่อผู้ใช้งาน');
    setBusy(true);
    setTimeout(() => {
      setBusy(false);
      onLoginSuccess({ name: username.trim(), role: 'Super Admin' });
    }, 450);
  };

  const biometric = async () => {
    setError('');
    setBusy(true);
    const ok = await authenticateBiometric();
    setBusy(false);
    if (ok) onLoginSuccess({ name: 'Biometric User', role: 'Admin' });
    else setError('ไม่สามารถยืนยันตัวตนด้วยไบโอเมตริกได้');
  };

  return <div className="login-screen">
    <div className="login-glow glow-a"/><div className="login-glow glow-b"/>
    <div className="login-layout">
      <div className="login-brand">
        <div className="logo-orbit"><span>🌱</span></div>
        <span className="eyebrow">LAMAY • SMART FARM</span>
        <h1>ฟาร์มที่ดี<br/><em>เริ่มจากระบบที่ดี</em></h1>
        <p>บริหารพื้นที่ คลังสินค้า บัญชี และข้อมูลการเกษตรอย่างเป็นระบบ</p>
        <div className="login-trust"><span>✓ ใช้งานง่าย</span><span>✓ Mobile First</span><span>✓ Offline Ready</span></div>
      </div>
      <div className="login-box">
        <div className="login-heading"><span className="mini-label">WELCOME BACK</span><h2>เข้าสู่ระบบ</h2><p>เข้าสู่ LAMAY Smart Farm ของคุณ</p></div>
        <form onSubmit={login}>
          <label>ชื่อผู้ใช้งาน<input value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" placeholder="เช่น Admin"/></label>
          <label>รหัสผ่าน<div className="password-field"><input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" placeholder="กรอกรหัสผ่าน"/><span>⌁</span></div></label>
          {error && <div className="form-error">! {error}</div>}
          <button className="button primary login-submit" disabled={busy}>{busy ? 'กำลังตรวจสอบ…' : 'เข้าสู่ระบบ →'}</button>
        </form>
        <div className="or"><span>หรือ</span></div>
        <button className="biometric" onClick={biometric} disabled={busy}><span>◉</span><div><b>ลายนิ้วมือ / Face ID</b><small>เข้าสู่ระบบอย่างรวดเร็ว</small></div><i>→</i></button>
        <p className="security-note">🔒 ข้อมูลของคุณถูกจัดเก็บอย่างปลอดภัยบนอุปกรณ์</p>
      </div>
    </div>
  </div>;
}
