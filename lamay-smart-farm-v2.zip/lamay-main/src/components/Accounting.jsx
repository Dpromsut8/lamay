import React, { useMemo, useState } from 'react';

const seed=[
 {id:1,type:'income',title:'ขายไข่ไก่',date:'29 ก.ค. 2026',amount:3200,cat:'ผลผลิต'},
 {id:2,type:'expense',title:'ซื้ออาหารปลา',date:'28 ก.ค. 2026',amount:1450,cat:'วัตถุดิบ'},
 {id:3,type:'income',title:'ขายผักสวนครัว',date:'26 ก.ค. 2026',amount:2100,cat:'ผลผลิต'},
 {id:4,type:'expense',title:'ค่าน้ำมันเครื่องสูบน้ำ',date:'25 ก.ค. 2026',amount:680,cat:'สาธารณูปโภค'},
];
export default function Accounting(){
 const [tx,setTx]=useState(seed); const [type,setType]=useState('income'); const [title,setTitle]=useState(''); const [amount,setAmount]=useState('');
 const income=useMemo(()=>tx.filter(x=>x.type==='income').reduce((a,x)=>a+x.amount,0)+9200,[tx]);
 const expense=useMemo(()=>tx.filter(x=>x.type==='expense').reduce((a,x)=>a+x.amount,0)+2070,[tx]);
 const add=e=>{e.preventDefault();if(!title||!amount)return;setTx([{id:Date.now(),type,title,date:'วันนี้',amount:Number(amount),cat:type==='income'?'รายรับ':'รายจ่าย'},...tx]);setTitle('');setAmount('')};
 return <div className="page-stack">
  <div className="account-summary"><div><span>รายรับรวม</span><strong>฿{income.toLocaleString('th-TH')}</strong><small>เดือนนี้</small></div><div><span>รายจ่ายรวม</span><strong>฿{expense.toLocaleString('th-TH')}</strong><small>เดือนนี้</small></div><div><span>คงเหลือสุทธิ</span><strong>฿{(income-expense).toLocaleString('th-TH')}</strong><small>ประมาณการ</small></div></div>
  <section className="section-card"><div className="section-heading"><div><span className="section-kicker">CASH FLOW</span><h2>บันทึกรายการ</h2></div></div>
   <form className="transaction-form" onSubmit={add}><div className="segmented"><button type="button" className={type==='income'?'active income':''} onClick={()=>setType('income')}>＋ รายรับ</button><button type="button" className={type==='expense'?'active expense':''} onClick={()=>setType('expense')}>− รายจ่าย</button></div><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="รายละเอียด เช่น ขายไข่ไก่"/><div className="money-input"><span>฿</span><input type="number" min="0" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0.00"/></div><button className="button primary" type="submit">บันทึก</button></form>
  </section>
  <section className="section-card"><div className="section-heading"><div><span className="section-kicker">RECENT</span><h2>รายการล่าสุด</h2></div></div><div className="transaction-list">{tx.map(x=><div className="transaction" key={x.id}><span className={`tx-icon ${x.type}`}>{x.type==='income'?'＋':'−'}</span><div><b>{x.title}</b><small>{x.cat} • {x.date}</small></div><strong className={x.type}>{x.type==='income'?'+':'−'}฿{x.amount.toLocaleString('th-TH')}</strong></div>)}</div></section>
 </div>
}
