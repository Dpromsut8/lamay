import React, { useRef, useState } from 'react';

export default function AIDoctor(){
 const input=useRef(); const [image,setImage]=useState(null); const [analyzing,setAnalyzing]=useState(false); const [result,setResult]=useState(null);
 const choose=e=>{const f=e.target.files?.[0];if(!f)return;setImage(URL.createObjectURL(f));setResult(null)};
 const analyze=()=>{if(!image)return;setAnalyzing(true);setTimeout(()=>{setAnalyzing(false);setResult({title:'เบื้องต้น: ใบมีอาการเครียดจากน้ำ / สภาพแวดล้อม',score:'84%',tips:['ตรวจความชื้นบริเวณโคนต้น','หลีกเลี่ยงการให้น้ำมากเกินในช่วงเย็น','ติดตามอาการอีกครั้งภายใน 24–48 ชม.']})},900)};
 return <div className="page-stack">
  <section className="ai-hero section-card"><div><span className="ai-orb">✦</span><span className="section-kicker">LAMAY AI DOCTOR</span><h2>ผู้ช่วยเกษตรอัจฉริยะ</h2><p>ถ่ายภาพพืชหรือใบที่มีอาการผิดปกติ แล้วให้ระบบช่วยวิเคราะห์เบื้องต้น</p><div className="ai-points"><span>✓ วิเคราะห์ภาพ</span><span>✓ คำแนะนำการดูแล</span><span>✓ บันทึกผลได้</span></div></div><div className="ai-scan-art">⌁<span>AI</span></div></section>
  <section className="section-card"><div className="section-heading"><div><span className="section-kicker">PLANT SCANNER</span><h2>วิเคราะห์ภาพพืช</h2></div></div>
   <input ref={input} type="file" accept="image/*" capture="environment" onChange={choose} hidden/>
   {!image?<button className="dropzone" onClick={()=>input.current?.click()}><span>📷</span><b>แตะเพื่อถ่ายภาพ / เลือกรูป</b><small>JPG, PNG • ภาพคมชัดจะช่วยให้วิเคราะห์ได้ดีขึ้น</small></button>:
   <div className="preview-box"><img src={image} alt="ภาพสำหรับวิเคราะห์"/><div><button className="button primary" onClick={analyze} disabled={analyzing}>{analyzing?'กำลังวิเคราะห์…':'✦ วิเคราะห์ด้วย AI'}</button><button className="button secondary" onClick={()=>{setImage(null);setResult(null)}}>เลือกรูปใหม่</button></div></div>}
   {result&&<div className="ai-result"><div className="result-score"><strong>{result.score}</strong><span>ความมั่นใจโดยประมาณ</span></div><div><span className="section-kicker">RESULT</span><h3>{result.title}</h3><ul>{result.tips.map(t=><li key={t}>{t}</li>)}</ul></div></div>}
   <p className="disclaimer">หมายเหตุ: ผลจาก AI เป็นข้อมูลเบื้องต้น ไม่ควรใช้แทนการวินิจฉัยโดยผู้เชี่ยวชาญด้านพืช</p>
  </section>
 </div>
}
