import React, { useState } from 'react';

const zones = [
  { id:'pond', title:'สระน้ำหลัก', area:'7 ไร่', icon:'💧', health:'ดี', desc:'แหล่งน้ำสำรองสำหรับระบบเกษตร', value:'78%' },
  { id:'forest', title:'โคก หนอง นา', area:'15 ไร่', icon:'🌾', health:'ดี', desc:'พื้นที่ปลูกพืชผสมผสานและไม้ยืนต้น', value:'92%' },
  { id:'greenhouse', title:'โรงเรือน', area:'—', icon:'🏡', health:'ปกติ', desc:'พื้นที่เพาะปลูกและอนุบาลต้นกล้า', value:'86%' },
  { id:'livestock', title:'โซนสัตว์เลี้ยง', area:'—', icon:'🐔', health:'ดี', desc:'ไก่ไข่ ปลา และระบบให้อาหาร', value:'95%' },
];

export default function FarmMap() {
  const [selected, setSelected] = useState('forest');
  const zone = zones.find(z => z.id === selected);
  return <div className="page-stack">
    <section className="section-card map-card">
      <div className="section-heading"><div><span className="section-kicker">FARM OVERVIEW</span><h2>ผังแปลงเกษตร <span className="muted">22 ไร่</span></h2></div><span className="live-pill"><i/> LIVE</span></div>
      <div className="farm-map">
        <div className="map-grid"/>
        <button className={`map-zone pond ${selected==='pond'?'selected':''}`} onClick={()=>setSelected('pond')}><span>💧</span><b>สระน้ำหลัก</b><small>7 ไร่</small></button>
        <button className={`map-zone forest ${selected==='forest'?'selected':''}`} onClick={()=>setSelected('forest')}><span>🌳</span><b>โคก หนอง นา</b><small>15 ไร่</small></button>
        <button className={`map-zone house ${selected==='greenhouse'?'selected':''}`} onClick={()=>setSelected('greenhouse')}><span>🏡</span><b>โรงเรือน</b><small>เกษตร</small></button>
        <button className={`map-zone animals ${selected==='livestock'?'selected':''}`} onClick={()=>setSelected('livestock')}><span>🐔</span><b>สัตว์เลี้ยง</b><small>ปศุสัตว์</small></button>
        <div className="map-pin">●</div>
      </div>
      <div className="map-detail"><div className="detail-icon">{zone.icon}</div><div><span>พื้นที่ที่เลือก</span><h3>{zone.title} <small>{zone.area}</small></h3><p>{zone.desc}</p></div><div className="health-score"><b>{zone.value}</b><span>สุขภาพ</span></div></div>
    </section>
    <div className="stats-grid two">
      {zones.map(z=><button className={`zone-list ${selected===z.id?'selected':''}`} key={z.id} onClick={()=>setSelected(z.id)}><span>{z.icon}</span><div><b>{z.title}</b><small>{z.area} • สุขภาพ{z.health}</small></div><strong>{z.value}</strong></button>)}
    </div>
  </div>;
}
