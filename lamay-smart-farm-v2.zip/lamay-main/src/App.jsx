import React, { useMemo, useState } from 'react';
import Login from './components/Login';
import FarmMap from './components/FarmMap';
import Inventory from './components/Inventory';
import Accounting from './components/Accounting';
import AIDoctor from './components/AIDoctor';

const tabs = [
  { id: 'overview', icon: '⌂', label: 'ภาพรวม' },
  { id: 'farm', icon: '⌖', label: 'แปลงเกษตร' },
  { id: 'inventory', icon: '▦', label: 'คลัง' },
  { id: 'accounting', icon: '฿', label: 'บัญชี' },
  { id: 'ai', icon: '✦', label: 'AI ผู้ช่วย' },
];

function Stat({ icon, label, value, hint, tone='green' }) {
  return <div className="stat-card">
    <div className={`stat-icon ${tone}`}>{icon}</div>
    <div className="stat-copy"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div>
  </div>;
}

function Overview({ onNavigate }) {
  const [aiVisible, setAiVisible] = useState(true);
  const [query, setQuery] = useState('');
  return <div className="page-stack">
    <section className="hero-card">
      <div className="hero-image" />
      <div className="hero-overlay" />
      <div className="hero-content">
        <span className="eyebrow">LAMAY SMART FARM • วันนี้</span>
        <h1>ดูแลฟาร์มให้เป็นระบบ<br/><em>ง่ายขึ้นทุกวัน</em></h1>
        <p>ภาพรวมพื้นที่ • คลังสินค้า • บัญชี • ผู้ช่วย AI อยู่ในที่เดียว</p>
        <div className="hero-actions">
          <button className="button primary" onClick={() => onNavigate('farm')}>⌖ ดูผังฟาร์ม</button>
          <button className="button glass" onClick={() => onNavigate('ai')}>✦ เปิด AI ผู้ช่วย</button>
        </div>
      </div>
      {aiVisible && <div className="floating-insight">
        <div className="insight-top"><span>✦ AI Insight</span><button className="icon-button" onClick={() => setAiVisible(false)} aria-label="ปิด">×</button></div>
        <strong>ชะอม • แนะนำดูแลวันนี้</strong>
        <p>แดดจัด น้ำปานกลาง และตัดแต่งกิ่งสม่ำเสมอเพื่อเร่งยอดอ่อน</p>
      </div>}
    </section>

    <div className="stats-grid">
      <Stat icon="⌖" label="พื้นที่ทั้งหมด" value="22 ไร่" hint="โคก หนอง นา" />
      <Stat icon="฿" label="รายรับเดือนนี้" value="฿14,500" hint="+8.4% จากเดือนก่อน" />
      <Stat icon="▣" label="คงคลัง" value="18 รายการ" hint="2 รายการใกล้หมด" tone="blue" />
      <Stat icon="◉" label="สุขภาพแปลง" value="92%" hint="อยู่ในเกณฑ์ดี" tone="amber" />
    </div>

    <section className="section-card quick-search">
      <div className="section-heading"><div><span className="section-kicker">ค้นหาเร็ว</span><h2>ค้นหาพืช / สินค้า / ความรู้</h2></div><span className="shortcut">⌘ K</span></div>
      <div className="search-wrap"><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="เช่น ชะอม, ปั๊มน้ำ, วิธีดูแล..." /><button onClick={() => onNavigate('inventory')}>ค้นหา</button></div>
      {query && <div className="search-result">ค้นหา “{query}” ในคลังและฐานความรู้ของฟาร์ม</div>}
    </section>

    <section className="section-card">
      <div className="section-heading"><div><span className="section-kicker">ทางลัด</span><h2>จัดการงานสำคัญ</h2></div></div>
      <div className="action-grid">
        <button className="action-tile" onClick={() => onNavigate('inventory')}><span>▦</span><strong>จัดการคลัง</strong><small>เพิ่ม / แก้ไข / ตรวจราคา</small></button>
        <button className="action-tile" onClick={() => onNavigate('accounting')}><span>฿</span><strong>บันทึกบัญชี</strong><small>รายรับ รายจ่าย และสรุป</small></button>
        <button className="action-tile" onClick={() => onNavigate('ai')}><span>✦</span><strong>วิเคราะห์พืช</strong><small>ภาพถ่ายและคำแนะนำ AI</small></button>
      </div>
    </section>

    <section className="section-card">
      <div className="section-heading"><div><span className="section-kicker">สถานะวันนี้</span><h2>ภาพรวมฟาร์ม</h2></div><button className="text-button" onClick={() => onNavigate('farm')}>ดูทั้งหมด →</button></div>
      <div className="status-list">
        <div><span className="status-dot good"/>ระบบน้ำ <strong>ทำงานปกติ</strong><small>อัปเดต 08:42</small></div>
        <div><span className="status-dot good"/>สระน้ำหลัก <strong>ระดับ 78%</strong><small>เพียงพอ 6 วัน</small></div>
        <div><span className="status-dot warn"/>วัสดุสิ้นเปลือง <strong>2 รายการใกล้หมด</strong><small>ควรตรวจสอบวันนี้</small></div>
      </div>
    </section>
  </div>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState('overview');

  const content = useMemo(() => {
    const nav = id => setTab(id);
    if (tab === 'farm') return <FarmMap />;
    if (tab === 'inventory') return <Inventory />;
    if (tab === 'accounting') return <Accounting />;
    if (tab === 'ai') return <AIDoctor />;
    return <Overview onNavigate={nav} />;
  }, [tab]);

  if (!user) return <Login onLoginSuccess={setUser} />;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand" onClick={() => setTab('overview')} role="button" tabIndex="0">
        <div className="brand-mark">L</div><div><strong>LAMAY</strong><span>SMART FARM</span></div>
      </div>
      <div className="top-actions">
        <div className="online"><i/> ระบบปกติ</div>
        <button className="user-chip" onClick={() => setUser(null)} title="ออกจากระบบ"><span>◉</span><b>{user.name || 'ผู้ดูแล'}</b><small>ออกจากระบบ</small></button>
      </div>
    </header>

    <main className="main">
      <div className="welcome-row"><div><span className="section-kicker">วันพุธ 29 กรกฎาคม 2026</span><h2>{tab === 'overview' ? 'สวัสดีครับ 👋' : tabs.find(t => t.id === tab)?.label}</h2></div><div className="weather">☀️ <b>29°C</b><span>นครศรีธรรมราช</span></div></div>
      {content}
    </main>

    <nav className="bottom-nav" aria-label="เมนูหลัก">
      {tabs.map(t => <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}><span>{t.icon}</span><small>{t.label}</small></button>)}
    </nav>
  </div>;
}
